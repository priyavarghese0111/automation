package base;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


import browser.DriverSetup;

public class ModularFunctions extends DriverSetup{
	
	
	
	
	/*******************Take ScreenShot**********************/
	public static void takeScreenShot(String filepath) {
		TakesScreenshot takesScreenShot = (TakesScreenshot) driver;
		File srcFile = takesScreenShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(filepath);
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (Exception e) {
			e.printStackTrace();
		}


	}


	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

	//hooks TBD - Coming Soon ! or Not 

}
