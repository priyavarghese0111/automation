package browser;


import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;

import utils.Configuration;

public class DriverSetup {

	//Configuration config =  new Configuration();

	public static WebDriver driver;
	public static Properties prop;
	public String browser_choice;

	public DriverSetup() {
		prop = Configuration.iniProperties();
	}
	public static WebDriver invokeBrowser() {
		System.out.println("Hello-> invoking Browser");
		String browser_choice = prop.getProperty("browserName");

		try {
			if(browser_choice.equalsIgnoreCase("firefox")) {
				System.out.println("hello im firefox");
				driver = DriverSetup.getFireFoxDriver();
			}else if(browser_choice.equalsIgnoreCase("msedge")){
				driver = DriverSetup.getEdgeDriver();
			}else if(browser_choice.equalsIgnoreCase("chrome")){
				System.out.println("hello im chrome");
				driver = DriverSetup.getChromeDriver();
			}else {
				throw new Exception("Invalid browser");
			}

		} catch (Exception e) {
			e.getMessage();
		}
		return driver;


	}

	/********************Chrome Browser***************************/
	public static WebDriver getChromeDriver() {
		System.out.println("this is chrome");
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--disable-infobars");
		co.addArguments("--disable-notifications");
		co.addArguments("--disable-maximized");
		//co.addArguments("--lang=en");
		WebDriver driver = new ChromeDriver(co);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		return driver;
	}

	/********************MS Edge Browser***************************/
	public static WebDriver getEdgeDriver() {
		EdgeOptions mseo = new EdgeOptions();
		mseo.addArguments("--disable-infobars");
		mseo.addArguments("--disable-notifications");
		mseo.addArguments("--disable-maximized");
		return driver;
	}

	/********************FireFox Browser***************************/
	public static WebDriver getFireFoxDriver() {
		FirefoxOptions fo =  new FirefoxOptions();
		fo.addArguments("--disable-infobars");
		fo.addArguments("--disable-notifications");
		fo.addArguments("--disable-maximized");
		return driver;
	}



}
