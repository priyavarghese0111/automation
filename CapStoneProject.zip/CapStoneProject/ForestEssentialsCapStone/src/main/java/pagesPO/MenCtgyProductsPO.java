package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class MenCtgyProductsPO {
	WebDriver driver;
	ElementalFunctions ef;
	public MenCtgyProductsPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(xpath = "//img[@alt='Hair Conditioner Amla, Honey & Mulethi']")
	WebElement hairCon;
	
	@FindBy(xpath = "//span[contains(text(),'Key Ingredients')]")
	WebElement hairConIngredents;
	
	@FindBy(xpath = "//a[@id='ingredint_link']")
	WebElement viewFullList;
	@FindBy(xpath = "//p[contains(text(),'** Certified Organic')]")
	WebElement Certification;
	
	public void goToHairConProduct() {
		ef.delay(1000);
		ef.scroll(hairCon);
		ef.clickElement(hairCon);
	}
	public void goToKeyIngredents() {
		ef.scroll(hairConIngredents);
	}
	public boolean checkViewFullListLink() {
		System.out.println(viewFullList.getText());
		return viewFullList.isDisplayed();
	}
	public void clickViewFullListLink() {
		ef.clickElement(viewFullList);
	}
	//p[contains(text(),'** Certified Organic')]
	public boolean getCertifiedOrganic() {
		System.out.println(Certification.getText());
		return Certification.isDisplayed();
	}
}
