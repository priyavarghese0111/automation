package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class IngredientsPage {

	
	WebDriver driver;
	ElementalFunctions ef;
	
	public IngredientsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(xpath = "//a[text()='Apricot Oil']" )
	public WebElement ApricotOil;
	
	@FindBy(xpath = "//span[@class='ingedient-detail-name']")
	public WebElement ResultText;
	
	public void click(WebElement element) {
		ef.clickElement(element);
	}
	
	public void scroll(WebElement element) {
		ef.scroll(element);
	}
	
	public String  GetText(WebElement element) {
		return ef.getElementText(element);
	}
}
