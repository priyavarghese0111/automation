package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class LoginPage {
	
	WebDriver driver;
	ElementalFunctions ef;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(name = "login[username]")
	public WebElement Email;
	
	@FindBy(name = "login[password]" )
	public WebElement Password;
	
	@FindBy(id = "send2")
	public WebElement SignInBtn;
	
	@FindBy(css = "li.header_account_link_list > a")
	public WebElement logout;
	
	public void insertText(String text,WebElement element) {
		ef.insertText(text, element);
		ef.delay(5000);
		
	}
	
	public void clickElement(WebElement element) {
		ef.delay(10000);
		ef.clickElement(element);
	
	}
	
	public void scroll(WebElement element) {
		ef.scroll(element);
	}

	public boolean checkUrl(String url) {
		return ef.checkurl(url);
	}
}
