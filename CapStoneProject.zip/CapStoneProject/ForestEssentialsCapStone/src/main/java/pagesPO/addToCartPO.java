package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class addToCartPO {
	WebDriver driver;
	ElementalFunctions efunc;
	
	public addToCartPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		efunc = new ElementalFunctions(driver);
	}
	@FindBy(css = " ul.ms-topmenu li.ms-level0.nav-2:nth-child(2) > a.ms-label")
	WebElement ctgyFace;
	
	@FindBy(css = ".nav-3:nth-child(3) > a.ms-label")
	WebElement ctgyBath_Body;
	
	@FindBy(xpath = "//a[@class='ms-label' and @href='/hair-care.html']")
	WebElement ctgyHair;
	
	
	
	@FindBy(linkText = "Anti Ageing")
	WebElement SubCtgyAntiAge;
	
	@FindBy(linkText = "Silk Soaps")
	WebElement SubCtgySilkSoap;
	

	
	
	@FindBy(xpath = "//img[@alt='Soundarya Radiance Cream With 24K Gold & SPF25']")
	WebElement prdct1;
	@FindBy(xpath = "//img[@alt='Nourishing Silk Soap Panchamrit']")
	WebElement prdct2;

	
	
	@FindBy(id = "product-addtocart-button-custom")
	WebElement addToBag;
	@FindBy(xpath = "//span[contains(text(),'Soundarya Radiance Cream With 24K Gold & SPF25')]")
	WebElement scrollrTo1;
	@FindBy(xpath = "//span[contains(text(),'Nourishing Silk Soap Panchamrit')]")
	WebElement scrollrTo2;
	
	
	@FindBy(xpath = "//a[@class='action showcart']")
	WebElement showCart;
	@FindBy(xpath = "//a[@class='action viewcart']")
	WebElement viewCart;
	
	@FindBy(xpath = "//img[@alt='Som Rasa Silk Skin Tint Gulab Pankh 3ml']")
	WebElement giftOption;
	
	@FindBy(xpath = "//button[contains(text(),'Add to Bag')]")
	WebElement giftAdd;
	
	public void addFromFaceCtgy() throws InterruptedException {
		
		// Perform hover action
		efunc.delay(3000);
		efunc.elementHover(ctgyFace);
		efunc.clickElement(SubCtgyAntiAge);
		efunc.scroll(prdct1);
		efunc.clickElement(prdct1);
		efunc.scroll(scrollrTo1);
		efunc.clickElement(addToBag);
		efunc.delay(3000);
		//ctgyFace.click();
	}
	public void addFromBathAndBody()  {
		efunc.scrollToTop(driver);
		efunc.delay(1000);
		efunc.elementHover(ctgyBath_Body);
		efunc.clickElement(SubCtgySilkSoap);
		efunc.scroll(prdct2);
		efunc.clickElement(prdct2);
		efunc.scroll(scrollrTo2);
		efunc.clickElement(addToBag);
		efunc.delay(4000);
	}
	public void goToCart() {
		efunc.scrollToTop(driver);
		efunc.clickElement(showCart);
		efunc.delay(1500);
		efunc.clickElement(viewCart);
	}
	
	public void addFreeGift() {
		
		efunc.clickElement(giftOption);
		efunc.clickElement(giftAdd);
	}

	
}
