package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class WishlistToCartPage {
	WebDriver driver;
	ElementalFunctions ef;
	
	public WishlistToCartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(xpath = "//header/div[1]/div[1]/div[3]/div[2]/ul[1]/li[2]/a[1]")
	public WebElement account1 ;
	
	@FindBy(css = "#block-collapsible-nav > ul > li:nth-child(5) > a" )
	public WebElement wishlist;
	
	@FindBy(xpath = "//li[1]/div[1]/div[1]/div[3]/div[1]/button[1]")
	public WebElement moveToBag;
	@FindBy(xpath = "//li[2]/div[1]/div[1]/div[3]/div[1]/button[1]")
	public WebElement moveToBag1;
	@FindBy (css="div.message.info.empty")
	public WebElement errMsg;
	
	public void clickEl(WebElement el) {
		ef.scroll(el);
		ef.clickElement(el);
		ef.delay(3000);
	}
	public boolean isPresent(WebElement el) {
		return ef.isPresent(el);
	}

}



