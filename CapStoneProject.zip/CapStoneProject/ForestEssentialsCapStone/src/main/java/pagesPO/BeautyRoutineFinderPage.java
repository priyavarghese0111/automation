package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class BeautyRoutineFinderPage {

	WebDriver driver;
	ElementalFunctions ef;
	
	public BeautyRoutineFinderPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(xpath ="//span[1]/a[1]")
	 public WebElement GetStarted;
	
	@FindBy(xpath = "//span[@class='checkmark']")
	public WebElement age;
	
	@FindBy(xpath = "//span[@data-value='Female']")
	public WebElement gender;
	
	@FindBy(xpath = "//label[@class='ri_label' and input[@value='Relatively relaxed. Have sufficient time for self-care.']]")
	public WebElement routine;
	
	@FindBy(id = "haircat")
	public WebElement category;
	
	@FindBy(xpath = "//label[@class='ri_label' and input[@value='Hair Loss']]")
	public WebElement concern;
	
	@FindBy(css = "#hairconcern > div.ri-next-button > a")
	public WebElement SeeRitual;
	
	
	@FindBy(id = "next1")
	public WebElement NextBtn1;
	
	@FindBy(id = "next2")
	public WebElement NextBtn2;
	
	@FindBy(id = "next3")
	public WebElement NextBtn3;
	
	@FindBy(id = "next4")
	public WebElement NextBtn4;
	
	
	@FindBy(xpath = "//h2[text()='1. Hair Oil']")
	public WebElement Result;
	
	public void clickElement(WebElement element) {
		ef.delay(2000);
		ef.clickElement(element);
		ef.delay(2000);

	}
	
	public String getresult(WebElement element) {
		return ef.getElementText(element);
	}
	
	public void scroll(WebElement element) {
		ef.delay(3000);
		ef.scroll(element);
		ef.delay(3000);
	}
	
	public void scrollToSpecifics(WebDriver driver) {
		ef.delay(3000);
		ef.scrollToSpecifics(driver);
		ef.delay(3000);
	}
	
	
	
}
