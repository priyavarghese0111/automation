package pagesPO;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class ContactUsPage {
	WebDriver driver;
	ElementalFunctions ef;
	
	public ContactUsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	@FindBy(id = "name")
	public WebElement cname;
	@FindBy(id = "email")
	public WebElement cemail;
	
	@FindBy(id = "telephone" )
	public WebElement phoneNo;
	@FindBy(id = "comment" )
	public WebElement comments;
	
	@FindBy(css = "#contact-form > div > div > button")
	public WebElement submitBtn;
	
	
	@FindBy(id = "message")
	public WebElement errmsg;
	
	@FindBy(xpath = "//body/div[@id='mm-0']/div[2]/main[1]/div[2]/div[2]/div[1]")
	public WebElement alertmsg;
	
	
	
	
	
	public void inputDetails(WebElement element,String details) {
		ef.delay(5000);
		element.sendKeys(details);
	}
	public boolean isPresentAl(Alert alert) {
		return ef.isPresent(alertmsg);
	}
	public boolean isPresent(WebElement el) {
		ef.delay(5000);
		return ef.isPresent(el);
	}
	public void clickBtn(WebElement element) {
		  //ef.delay(6000);
		  ef.scroll(element);
		  ef.clickElement(element);
		  ef.delay(7000);
		 
	  }
}

	


