package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class SrchResultPagePO {
	WebDriver driver;
	ElementalFunctions ef;
	public SrchResultPagePO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		ef = new ElementalFunctions(driver);
	}

	@FindBy(xpath = "//div[contains(text(),'Your search returned no results.')]")
	WebElement invalidRslt;
	
	
	
	public boolean getResult() {
		ef.delay(2000);
		try {
			
			return invalidRslt.isDisplayed();
			
		} catch (Exception e) {
			System.out.println("Your search returned no results.");
			return false;
		}

	}
}
