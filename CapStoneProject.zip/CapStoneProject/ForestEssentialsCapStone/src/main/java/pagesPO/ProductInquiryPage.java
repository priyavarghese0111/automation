package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class ProductInquiryPage {
	private WebDriver driver;
	  private ElementalFunctions ef;
	  
	  public ProductInquiryPage(WebDriver driver) {
		  this.driver=driver;
		  PageFactory.initElements(driver, this);
			ef=new ElementalFunctions(driver);
	  }
	  @FindBy(css="button[class='yotpo-default-button yotpo-icon-btn write-question-review-button write-button mL5 write-question-button']")
		private WebElement askQuestionBtn;
		@FindBy(id="yotpo_input_question_content")
		public WebElement question;
		@FindBy(id="yotpo_input_question_username")
		public WebElement qname;
		@FindBy(id="yotpo_input_question_email")
		public WebElement qemail;
		@FindBy(css="#write-question-tabpanel > div.form-element.submit-button > input")
		public WebElement postbtn;
		@FindBy(css=" div.write-question-content > div > div > label > span.form-input-error")
		public WebElement qerrmsg;
		@FindBy(css="div.form-element.name-input.visible > label > span.form-input-error")
		public WebElement unameErrmsg;
		@FindBy(css="div.form-element.email-input.visible > label > span.form-input-error")
		public WebElement emailErrmsg;
		@FindBy(css="#write-question-tabpanel > div.form-element.submit-button > span")
		public WebElement postErrmsg;
		@FindBy(xpath="//span[contains(text(),'Thank you for posting a question!')]")
		public WebElement thankyMsg;
		
		
		
		 public void clickAskQuestion() {
			 ef.scroll(askQuestionBtn);
			 ef.clickElement(askQuestionBtn);
		 }
		 public void enterQuestion(WebElement el,String txt) {
			    question.clear();
				question.sendKeys(txt);
				
			}
			public void enterName(WebElement el,String txt) {
				qname.clear();
				qname.sendKeys(txt);
			}
			
			public void enterEmail(WebElement el,String txt) {
				    qemail.clear();
					qemail.sendKeys(txt);
				
			
			}
			public void clickPostBtn() {
				ef.clickElement(postbtn);
				ef.delay(5000);
			}
			public boolean isPresent(WebElement el) {
				
				return ef.isPresent(el);
			}
}

