package pagesPO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class ShopByConcernPage_TBD_ {
	WebDriver driver;
	ElementalFunctions ef;
	
	public ShopByConcernPage_TBD_(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	  @FindBy(xpath="//main[@id='maincontent']/div[2]/div/div[16]/div/div/div/div/div[2]/div/ol/div/div/div[6]/li/div/div/div/h3/a/span")
	  public WebElement clickConcern;
	
	  @FindBy(xpath= "//main[@id='maincontent']/div[2]/div/div/h1")
	  public WebElement concernHead;
	  
	  public void clickElement(WebElement el) {
		     ef.delay(5000);
		     ef.clickElement(el);
			
		}
	  public boolean isConcernTrue() {
		  ef.delay(5000);
		 String txt= ef.getElementText(concernHead);
		  return txt.contains("Hair Loss");
	  }
	  
	  
}