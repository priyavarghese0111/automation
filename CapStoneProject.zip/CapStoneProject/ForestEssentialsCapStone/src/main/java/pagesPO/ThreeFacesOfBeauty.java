package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class ThreeFacesOfBeauty {
	WebDriver driver;
	ElementalFunctions ef;
	
	public ThreeFacesOfBeauty(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		ef = new ElementalFunctions(driver);
	}
	
	@FindBy(xpath = "//h1[contains(text(),\"Ayurveda equates Vata's beauty to the wind\")]")
	WebElement vataDesc;
	@FindBy(xpath = "//h1[contains(text(),\"Ayurveda equates Pitta's beauty to fire\")]")
	WebElement pittaDesc;
	@FindBy(xpath = "//h1[contains(text(),'Ayurveda describes Kapha’s beauty as the Earth’s s')]")
	WebElement kaphaDesc;
	
	
	public WebElement getVata() {
		return  vataDesc;
	}
	public WebElement getKapha() {
		return  kaphaDesc;
	}
	public WebElement getPitta() {
		return  pittaDesc;
	}
	
	public void findVataDesc() {
		
		ef.scroll(vataDesc);
		ef.delay(2000);
	}
	public void findKaphaDesc() {
		
		ef.scroll(kaphaDesc);
		ef.delay(2000);
	}
	public void findPittaDesc() {
		
		ef.scroll(pittaDesc);
		ef.delay(2000);
	}

}
