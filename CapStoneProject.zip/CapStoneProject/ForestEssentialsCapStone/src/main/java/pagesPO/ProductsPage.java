package pagesPO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ElementalFunctions;

public class ProductsPage {
	WebDriver driver;
	ElementalFunctions ef;
	
	public ProductsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	
	  @FindBy(css=" div > div.product.media > a.action.towishlist")
	  public WebElement wishlistBtn;
	
	  @FindBy(id = "codvalue")
	  public WebElement PincodeField;
	  
	  @FindBy(id = "codcheck-button")
	  public WebElement CheckBtn;
	  
	  
	  @FindBy(css = "#successmsg3 > div")
	  public WebElement SuccessMsg;
	  
	  @FindBy(css = "#errormsg2 > div")
	  public WebElement ErrorMsg;
	  
	  @FindBy(css = "#product_detailed_content > div.how-to-use-content-section > div > div > h2 > span")
	  public WebElement HowToUse;
	  
	   public void clickWishlistIcon() {
		 // ef.delay(5000);
		  ef.scroll(wishlistBtn);
		  ef.clickElement(wishlistBtn);
		  ef.delay(2000);
       }
	   
	   
	   public void scroll(WebElement element) {
			ef.scroll(element);
		}
	   
	  public void InsertPin(String text ,WebElement element) {
		  ef.insertText(text , element);
	  }
	  
	  public void clickCheckBtn(WebElement element) {
		  ef.clickElement(element);
		  ef.delay(3000);
	  }
	  
	  public String getMsg(WebElement element) {
		  String text = ef.getElementText(element);
		  return text;
	  }
	  
	  public void scrollToSpecifics(WebDriver driver) {
			ef.delay(3000);
			ef.scrollToSpecifics(driver);
			ef.delay(3000);
		}
}
