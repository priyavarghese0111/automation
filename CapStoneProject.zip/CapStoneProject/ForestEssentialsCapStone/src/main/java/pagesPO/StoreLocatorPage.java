package pagesPO;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ElementalFunctions;

public class StoreLocatorPage {
	WebDriver driver;
	ElementalFunctions ef;
	
	public StoreLocatorPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	@FindBy(name = "address")
	public WebElement searchfield;
	@FindBy(css = "#amlocator-radius6665f1d8668a8")
    private WebElement suggestions;
	
	@FindBy(css = "button[class='button']")
    public WebElement searchBtn;
	
	@FindBy(name = "leftLocation")
	 public WebElement locationResults;
	

	 public void enterIntoSearch(WebElement el,String txt) {
		 searchfield.clear();
		 searchfield.sendKeys(txt);
		 ef.delay(5000);
		 
		 
		// Wait for dropdown suggestions to appear
		 //WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		 //WebElement selectElement=wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#amlocator-radius6665f1d8668a8")));
		 
		 
		 //List <WebElement> suggestions=wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//option[contains(text(),'100')]")));
	       // wait.until(ExpectedConditions.visibilityOf(firstSuggestion));

	        // Select a locator from the dropdown   
//		 if(suggestions.size()>0) {
//			 suggestions.get(0).click();
//		 }
		 
		    
	    

	        // Wait for the map to load 
	      //  wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("leftLocation")));
			
    }
	 public void enterIntoSearchClickEnter() {
		 ef.delay(5000);
		 searchfield.clear();
		 searchfield.sendKeys(Keys.ENTER);
		 ef.delay(5000);
		 
	}
	 
	 public void clickElement(WebElement el) {
		 ef.clickElement(el);
	 }
	 public boolean elementPresent(WebElement el) {
		 return ef.isPresent(el);
	 }
	 
	 
}

