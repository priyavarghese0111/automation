package pagesPO;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.ElementalFunctions;

public class HomePage {
	
	WebDriver driver;
	ElementalFunctions ef;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		ef = new ElementalFunctions(driver);
	}
	/***************************NavBar Categories******************************/
	@FindBy(xpath = "//a[@class='ms-label ' and contains(@href, '/facial-care.html')]")
	WebElement ctgyFace;
	@FindBy(css = ".nav-3:nth-child(3) > a.ms-label")
	WebElement ctgyBath_Body;
	@FindBy(xpath = "//a[@class='ms-label' and @href='/hair-care.html']")
	WebElement ctgyHair;
	@FindBy(xpath = "//a[@href='/men-care.html' and @class='ms-label ']")
	WebElement ctgyMen;
	@FindBy(xpath = "//a[@href='/about-us' and @class='ms-label ']")
	WebElement ctgyAboutUs;
	/***************************************************************************/
	
	/***************************NavBar Sub Categories******************************/
	@FindBy(linkText = "Anti Ageing")
	WebElement SubCtgyAntiAge;
	@FindBy(linkText = "Silk Soaps")
	WebElement SubCtgySilkSoap;
	@FindBy(linkText = "Hair Care")
	WebElement SubCtgyHairCare;
	@FindBy(linkText = "Face Moisturizers")
	WebElement SubCtgyFaceMoisturizers;
	@FindBy(linkText = "Discover Vata")
	WebElement SubCtgyVata;
	@FindBy(linkText = "Discover Pitta")
	WebElement SubCtgyPitta;
	@FindBy(linkText = "Discover Kapha")
	WebElement SubCtgyKapha;
	/***************************************************************************/
	
	/***********************Cart Navigation**************/
	@FindBy(css = "a.action.showcart:nth-child(1)")
	WebElement showCart;
	@FindBy(css = " a.action.viewcart")
	WebElement viewCart;
	/****************************************************/
	
	/****************Hover Over Categories in HomePage Navbar**********************/

	public void hoverOverCtgyFace() {
		ef.elementHover(ctgyFace);
	}
	public void hoverOverCtgyBody() {
		ef.scrollToTop(driver);
		ef.delay(1000);
		ef.elementHover(ctgyBath_Body);
	}
	public void hoverOverCtgyMen() {
		ef.elementHover(ctgyMen);
	}
	public void hoverOverCtgyAboutUs() {
		ef.elementHover(ctgyAboutUs);
	}
	/*****************************************************************************/
	
	public void faceSubCtgy(){
		ef.clickElement(SubCtgyAntiAge);
	}
	public void bodySubCtgy(){
		ef.clickElement(SubCtgySilkSoap);
	}
	public void faceSubCtgyMoisturizer() {
		ef.clickElement(SubCtgyFaceMoisturizers);
	}
	
	
	public WebElement getVataSubCtgyLink(){
		return SubCtgyVata;
	}
	public WebElement getPittaSubCtgyLink(){
		return SubCtgyPitta;
	}
	public WebElement getKaphaSubCtgyLink(){
		return SubCtgyKapha;
	}
	
	
	
	public void goToCart(){
		ef.scrollToTop(driver);
		driver.navigate().refresh();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement showCartBtn = wait.until(ExpectedConditions.elementToBeClickable(showCart));
		ef.clickElement(showCartBtn);
		WebElement viewCartBtn = wait.until(ExpectedConditions.elementToBeClickable(viewCart));
		ef.clickElement(viewCartBtn);
	}
	@FindBy(xpath  = "//label[@class='label' and @for='search' and @data-role='minisearch-label']")
	WebElement srchBtn;
	@FindBy(xpath = "//input[@id='search'][not(@aria-expanded='true')]")
	WebElement srchBar;
	
	/***********************Cart Navigation**************/

	public void clickSrchBtnIcn() {
		ef.clickElement(srchBtn);
	}
	
	public SrchResultPagePO getSrchText(String srchTxt) {
		srchBar.sendKeys(srchTxt, Keys.ENTER);
		return new SrchResultPagePO(driver);
	}
	public MenCtgyProductsPO hairSubCtgy(){
		ef.clickElement(SubCtgyHairCare);
		return new MenCtgyProductsPO(driver);
	}
	
	@FindBy(xpath = "//p[@class='newletter-contents']")
	WebElement newsLetterTitle;
	@FindBy(xpath = "//input[@id='custom_name']")
	WebElement newsLetterNameField;
	
	@FindBy(xpath = "//div[@id='custom_name-error']")
	WebElement newsLetterNameErrMsg;
	
	@FindBy(xpath = "//input[@id='newsletter']")
	WebElement newsLetterEmailField;
	@FindBy(xpath = "//div[@id='newsletter-error']")
	WebElement newsLetterEmailErrMsg;
	@FindBy(xpath = "//input[@id='agree']")
	WebElement newsLetterCheckBox;
	
	@FindBy(xpath = "//button[@title='Subscribe']")
	WebElement newsLetterSubscribe;
	
	@FindBy(xpath = "//div[@data-bind='html: message.text']")
	WebElement newsLetterResponse;
	/**************************************************/
	public void scrollToNewsLetter() {
		ef.delay(6000);
		ef.scroll(newsLetterTitle);
		ef.delay(2000);
		
	}
	
	public WebElement getNewsLetterName() {
		return newsLetterNameField;
	}
	public WebElement getNewsLetterEmail() {
		return newsLetterEmailField;
	}
	public WebElement getNewsLetterCheckBox() {
		return newsLetterCheckBox;
	}
	public WebElement getNewsLetterSubBtn() {
		return newsLetterSubscribe;
	}
	
	public WebElement getSubResponse() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement getResponse = wait.until(ExpectedConditions.visibilityOf(newsLetterResponse));
		return getResponse;
	}
	public WebElement getNameErrMsg(){
		return newsLetterNameErrMsg;
	}
	public WebElement getEmailErrMsg(){
		return newsLetterEmailErrMsg;
	}
	/*************************************************************/
	@FindBy(css ="div.header-links ul > li:nth-child(1) > a")
	 public WebElement Account;
	
	@FindBy(linkText="Light Day Lotion Lavender & Neroli SPF25")
	  public WebElement productClick;
	
	@FindBy(css="#nav-21 > a")
	  public WebElement Exclusives;
	
	@FindBy(linkText = "Beauty Routine Finder")
	public WebElement BeautyRoutineLink;
	

	@FindBy(css = "#nav-15 > a")
	public WebElement AboutUs;
	
	@FindBy(linkText = "Our Ingredients")
	public WebElement OurIngredients;
	

	@FindBy(css=" div.store-links > a")
	  public WebElement stores;
	  
	@FindBy(css="div > p:nth-child(3) > a")
	  public WebElement contactUs;
	
	@FindBy(xpath="//h2[contains(text(),'Shop By Concern')]")
	  public WebElement shopByConcern;
	
	
	
	public LoginPage click(WebElement element) {
		ef.clickElement(element);
		return new LoginPage(driver);
	}
	
	public void selectProduct() {
		  ef.delay(3000);
		  ef.scroll(productClick);
		  ef.clickElement(productClick);
	  }
	public void clickEl(WebElement el) {
		ef.scroll(el);
		ef.delay(3000);
		ef.clickElement(el);
		ef.delay(3000);
	}
	
	public ProductsPage click1(WebElement element) {
		ef.delay(3000);
		ef.clickElement(element);
		return new ProductsPage(driver);
	}
	 public boolean elementPresent(WebElement el) {
		 
		 ef.delay(8000);
		 return ef.isPresent(el);
	 }
	public StoreLocatorPage click2(WebElement element) {
		ef.clickElement(element);
		return new StoreLocatorPage(driver);
	}
	
	public void HoverElement(WebElement element) {
		ef.elementHover(element);
	}
	

	public BeautyRoutineFinderPage click3(WebElement element) {
		ef.clickElement(element);
		return new BeautyRoutineFinderPage(driver);
	}
	
	public IngredientsPage click4(WebElement element) {
		ef.clickElement(element);
		return new IngredientsPage(driver);
	}

}
