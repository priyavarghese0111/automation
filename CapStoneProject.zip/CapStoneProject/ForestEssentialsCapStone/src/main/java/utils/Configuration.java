package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class Configuration {
	private static Properties objProp;
	 //static String path = "C:\\JavaProjects\\ForestEssentialsCapstone\\src\\test\\resources\\objectRepository\\object.properties";
	public static Properties iniProperties() {
		if(objProp==null) {
			objProp =  new Properties();
			try {
				System.out.println("Configuration->Running");
				FileInputStream file =  new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\objectRepository\\object.properties");
				//FileInputStream file =  new FileInputStream(path);
				
				objProp.load(file);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return objProp;
		
	}

}
