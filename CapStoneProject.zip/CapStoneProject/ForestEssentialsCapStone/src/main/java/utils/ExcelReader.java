package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

		public static String[][] getData(String path, String sheetName) throws IOException {
			FileInputStream file = new FileInputStream(new File(path));
			XSSFWorkbook workbook =  new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			//get total no of rows
			int rowCount = sheet.getPhysicalNumberOfRows();
			System.out.println("Total No of Rows : "+rowCount);
			//get total no of colums
			int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
			System.out.println("Total No of Cols : "+colCount);
			
			String[][] data = new String[rowCount][colCount];
			DataFormatter df = new DataFormatter();
			for(int i = 0; i < rowCount; i++){
				for(int j = 0; j < colCount; j++){
					data[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
				}
			}
			return data;
			
		}
		public static int getRowCount(String path, String sheetName) throws IOException{
			FileInputStream file = new FileInputStream(new File(path));
			XSSFWorkbook workbook =  new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			int rowCount_ = sheet.getPhysicalNumberOfRows();
			return rowCount_;
		}
		public static int getColCount(String path, String sheetName) throws IOException{
			FileInputStream file = new FileInputStream(new File(path));
			XSSFWorkbook workbook =  new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			int colCount_ = sheet.getRow(0).getPhysicalNumberOfCells();
			return colCount_;
		}
		
}
