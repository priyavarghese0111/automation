package utils;



import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import base.ModularFunctions;

public class ExtentManager {

	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;

	public static ExtentReports createInstance() {
		try {
			String repname = "TestReport-" + ModularFunctions.getTimeStamp() + ".html";
			htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "//Reports//" + repname);

			htmlReporter.config().setDocumentTitle("Extent Report Forest Essentials");
			htmlReporter.config().setReportName("Test Report");
			htmlReporter.config().setTimelineEnabled(true);
			htmlReporter.config().setTheme(Theme.DARK);
			htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");

			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("OS", "Windows");
			extent.setSystemInfo("Host Name", "localhost");
			extent.setSystemInfo("Environment", "QA");
			extent.setSystemInfo("User Name", "Team5");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return extent;
	}
}
