package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.StoreLocatorPage;
import utils.ExtentReportsListener;
@Listeners(ExtentReportsListener.class)
public class StoreLocatorTest extends ModularFunctions{
	HomePage hp;
	StoreLocatorPage sp;
  @Test(priority=0)
  public void verify_StoreLocatorValidSearch() {
	  hp=new HomePage(driver);
	  sp=new StoreLocatorPage(driver);
	  hp.click2(hp.stores);
	  sp.enterIntoSearch(sp.searchfield,prop.getProperty("storelocatesearch")); //manually select from suggestions
	  sp.clickElement(sp.searchBtn);
	  AssertJUnit.assertTrue(sp.elementPresent(sp.locationResults)); //shows the nearby location as per the selected location
	  
  }
  @Test(priority=1)
  public void verify_StoreLocatorValidSearch_ClickEnter() {

	  sp.enterIntoSearch(sp.searchfield,prop.getProperty("storelocatesearch"));
	  sp.enterIntoSearchClickEnter();
	 
	  String alert=driver.switchTo().alert().getText();
	  AssertJUnit.assertTrue(alert.contains("choose address")); //shows an alert on entering any values-happens only on clicking ENTER
	  driver.switchTo().alert().accept();
	  
  }
  @Test(priority=3)
  public void verify_StoreLocator_NullSearch() {

	  //sp.enterIntoSearch(sp.searchfield,prop.getProperty(" "));
	  sp.clickElement(sp.searchBtn);
	  AssertJUnit.assertTrue(sp.elementPresent(sp.locationResults)); //shows nearby location
	  
  }
  
  
  
  @BeforeClass
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
  }
  

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }
}
