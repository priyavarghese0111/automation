package testCases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.AssertJUnit.assertTrue;

import java.time.Duration;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.BeautyRoutineFinderPage;
import pagesPO.HomePage;
import utils.ExtentReportsListener;


@Listeners(ExtentReportsListener.class)
public class BeautyRoutineTest extends ModularFunctions{
	
	HomePage hp;
	BeautyRoutineFinderPage bp;
	
	 
	  @BeforeMethod
	  public void beforeClass() {
		  driver = invokeBrowser();
		  driver.get(prop.getProperty("baseURL"));
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		  hp = new HomePage(driver);
		  
	  }
	  
	  @Test(priority=0)
	  public void checkLinkPresent() {
		  hp.HoverElement(hp.Exclusives);
		  AssertJUnit.assertTrue(hp.BeautyRoutineLink.isDisplayed());
	  }
	  
	  @Test(priority=1,dependsOnMethods = "checkLinkPresent")
	  public void checkRoutineFinder() throws InterruptedException {
		  hp.HoverElement(hp.Exclusives);
		  bp = hp.click3(hp.BeautyRoutineLink);
		  bp.scroll(bp.GetStarted);
		  bp.clickElement(bp.GetStarted);
		  bp.clickElement(bp.age);
		  bp.scrollToSpecifics(driver);
//		  Thread.sleep(3000);
		  bp.clickElement(bp.NextBtn1);
//		  Thread.sleep(3000);
		  bp.clickElement(bp.gender);
		  bp.scrollToSpecifics(driver);
//		  Thread.sleep(3000);
		  bp.clickElement(bp.NextBtn2);
		  bp.clickElement(bp.routine);
		  bp.scrollToSpecifics(driver);
//		  Thread.sleep(3000);
		  bp.clickElement(bp.NextBtn3);
		  bp.clickElement(bp.category);
		  bp.scrollToSpecifics(driver);
//		  Thread.sleep(3000);
		  bp.clickElement(bp.NextBtn4);
		  bp.clickElement(bp.concern);
		  bp.scrollToSpecifics(driver);
		  bp.clickElement(bp.SeeRitual);
		  
		  AssertJUnit.assertTrue(bp.getresult(bp.Result).contains("Hair"));
	  }
	  

	  
	  @AfterMethod
	  public void afterClass() {
				driver.quit();
			}
}

