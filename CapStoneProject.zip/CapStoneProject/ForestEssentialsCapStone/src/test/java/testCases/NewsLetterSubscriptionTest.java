package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;


import base.ElementalFunctions;
import base.ModularFunctions;
import pagesPO.HomePage;
import dataProvider.DataProviderUtility;


import org.openqa.selenium.WebDriver;


public class NewsLetterSubscriptionTest extends ModularFunctions{
	WebDriver driver;
	HomePage hp;
	ElementalFunctions ef;
	@Test(dataProvider = "NewsLetterData",  dataProviderClass = DataProviderUtility.class, priority = 2)
	public void validNewsLetterSub(String username, String userEmail) {
		hp.scrollToNewsLetter();
		ef.insertText(username, hp.getNewsLetterName());
		ef.insertText(userEmail, hp.getNewsLetterEmail());
		ef.clickElement(hp.getNewsLetterCheckBox());
		ef.clickElement(hp.getNewsLetterSubBtn());
		//Submission response is not beign displayed
		AssertJUnit.assertTrue(hp.getSubResponse().isDisplayed());
		System.out.println("Ok");
		System.out.println("Submission response is not beign displayed");
	}
	@Test(priority =  0)
	public void nullNewsLetterSub() {
		hp.scrollToNewsLetter();
		ef.clickElement(hp.getNewsLetterSubBtn());
		boolean result = hp.getNameErrMsg().isDisplayed()&hp.getEmailErrMsg().isDisplayed();
		AssertJUnit.assertTrue(result);
		System.out.println("Null Test Ok");
	}
	@Test(priority =  1)
	public void invalidNewsLetterSub() {
		hp.scrollToNewsLetter();
		ef.insertText(prop.getProperty("invalidNewsLetterName"), hp.getNewsLetterName());
		ef.insertText(prop.getProperty("invalidNewsLetterMailId"), hp.getNewsLetterEmail());
		ef.clickElement(hp.getNewsLetterCheckBox());
		ef.clickElement(hp.getNewsLetterSubBtn());
		boolean result = hp.getEmailErrMsg().isDisplayed();
		AssertJUnit.assertTrue(result);
		System.out.println("InvalidTest Test Ok");
	}
	
	@BeforeClass
	public void beforeClass() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseURL"));
		hp = new HomePage(driver);
		ef= new ElementalFunctions(driver);
	}

	@AfterClass
	public void afterClass() {
		//driver.quit();
	}

}
