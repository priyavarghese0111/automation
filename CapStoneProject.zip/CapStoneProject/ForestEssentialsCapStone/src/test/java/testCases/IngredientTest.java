package testCases;

import static org.testng.AssertJUnit.assertTrue;
import org.testng.annotations.Test;
import java.time.Duration;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.IngredientsPage;

public class IngredientTest extends ModularFunctions {

	HomePage hp;
	IngredientsPage ip;
	
	 @BeforeMethod
	  public void beforeClass() {
		  driver = invokeBrowser();
		  driver.get(prop.getProperty("baseURL"));
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		  hp = new HomePage(driver);
		  
	  }
	 
	 @Test(priority=0)
	 public void TestLinkPresent() {
		 hp.HoverElement(hp.AboutUs);
		 assertTrue(hp.OurIngredients.isDisplayed());		 
	 }
	 
	 @Test(priority=1,dependsOnMethods = "TestLinkPresent")
	 public void TestIngredients() {
		 hp.HoverElement(hp.AboutUs);
		 ip = hp.click4(hp.OurIngredients);
		 ip.scroll(ip.ApricotOil);
		 ip.click(ip.ApricotOil);
		 assertTrue(ip.GetText(ip.ResultText).contains("Apricot Oil"));
	 }
	 
	 @AfterMethod
	  public void afterClass() {
				driver.quit();
			}
	 
	
}
