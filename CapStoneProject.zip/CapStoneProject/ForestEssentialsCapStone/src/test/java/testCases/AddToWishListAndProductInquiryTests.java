package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import static org.testng.AssertJUnit.assertTrue;

import java.time.Duration;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.LoginPage;
import pagesPO.ProductInquiryPage;
import pagesPO.ProductsPage;

public class AddToWishListAndProductInquiryTests extends ModularFunctions {
	HomePage hp;
	//Properties prop = Configuration.iniProperties();
	ProductInquiryPage pi;
	LoginPage lp;
	ProductsPage po;
	
  @Test (priority=2)
  public void verifyAddtoWishlist_withoutLogin() {
	  po=new ProductsPage(driver);
	  po.clickWishlistIcon();  
	 AssertJUnit.assertTrue(driver.getCurrentUrl().contains("login")); //The user gets taken to the login page
	 
  }
  @Test (priority=3, dependsOnMethods = "verifyAddtoWishlist_withoutLogin")
  public void verifyAddtoWishlist_withLogin() {
	  lp=new LoginPage(driver);
	  lp.insertText(prop.getProperty("validemail"), lp.Email);
	  lp.insertText(prop.getProperty("validpwd"), lp.Password);
	  lp.scroll(lp.SignInBtn);
	  lp.clickElement(lp.SignInBtn);
	  AssertJUnit.assertTrue(driver.getCurrentUrl().contains("wishlist"));  //the product gets added to the wish list and gets redirected to Wish list page after successful login
	  
  }
  
  @Test (priority=1)
  public void verifyProductInquiry_valid() {
	  hp=new HomePage(driver);
	  pi =new ProductInquiryPage(driver);
//	  hp.selectProduct();
//	  pi.clickAskQuestion();
	  pi.enterQuestion(pi.question,prop.getProperty("question"));
	  pi.enterName(pi.qname,prop.getProperty("qname"));
	  pi.enterEmail(pi.qemail,prop.getProperty("qemail"));
	  pi.clickPostBtn();;
	  AssertJUnit.assertTrue(pi.isPresent(pi.thankyMsg));
	  
	    
  }
  @Test (priority=0)
  public void verifyProductInquiry_Invalid() {
	  hp=new HomePage(driver);
	  pi = new ProductInquiryPage(driver);
	  hp.selectProduct();
	  pi.clickAskQuestion();
	  pi.enterQuestion(pi.question," ");
	  pi.enterName(pi.qname," ");
	  pi.enterEmail(pi.qemail,prop.getProperty("Invqemail"));
	  pi.clickPostBtn();
	  AssertJUnit.assertTrue(pi.isPresent(pi.qerrmsg));
	  AssertJUnit.assertTrue(pi.isPresent(pi.unameErrmsg));
	  AssertJUnit.assertTrue(pi.isPresent(pi.emailErrmsg));
	  AssertJUnit.assertTrue(pi.isPresent(pi.postErrmsg));
	      
  }
  
  @BeforeClass
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
  }
  

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}

