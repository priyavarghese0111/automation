package testCases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utils.ExtentReportsListener;
import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.LoginPage;

@Listeners(ExtentReportsListener.class)
public class LoginTest extends ModularFunctions {
	
	HomePage hp;
	LoginPage lp;
	
  
  @BeforeMethod
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	  hp = new HomePage(driver);
	  
  }
  
  @Test(priority=2)
  public void PosLoginTest() throws InterruptedException {
	  lp = hp.click(hp.Account);
	  lp.insertText(prop.getProperty("validemail"), lp.Email);
	  lp.insertText(prop.getProperty("validpwd"), lp.Password);  
	  lp.scroll(lp.SignInBtn);
	  lp.clickElement(lp.SignInBtn);
	  AssertJUnit.assertTrue(lp.checkUrl(prop.getProperty("dashboardUrl")));

	  
  }
  
  
  @Test(priority=1)
  public void NegLoginTest() {
	  lp = hp.click(hp.Account);
	  lp.insertText(prop.getProperty("invalidemail"), lp.Email);
	  lp.insertText(prop.getProperty("invalidpwd"), lp.Password);	
	  lp.scroll(lp.SignInBtn);
	  lp.clickElement(lp.SignInBtn);
	  AssertJUnit.assertTrue(lp.checkUrl(prop.getProperty("loginUrl")));
	  
  }
  
  @Test(priority=0)
  public void NullLoginTest() {
	  lp = hp.click(hp.Account);
	  lp.Email.clear();;
	  lp.Password.clear();	
	  lp.scroll(lp.SignInBtn);
	  lp.clickElement(lp.SignInBtn);
	  AssertJUnit.assertTrue(lp.checkUrl(prop.getProperty("loginUrl")));
	  
  }
  

  @AfterMethod
  public void afterClass() {
			driver.quit();
		}
  }


