package testCases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.AssertJUnit.assertTrue;
import org.testng.annotations.Test;
import java.time.Duration;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.ProductsPage;
import utils.ExtentReportsListener;



@Listeners(ExtentReportsListener.class)
public class PinCodeTest extends ModularFunctions {
	
	HomePage hp;
	ProductsPage po;
	
  
  @BeforeMethod
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	  hp = new HomePage(driver);
	  po = new ProductsPage(driver);
	  po.scroll(hp.productClick);
	  po = hp.click1(hp.productClick);
	  
  }
  
  @Test(priority=0)
  public void validPinTest() {
	 
	  po.InsertPin(prop.getProperty("validPin"),po.PincodeField);
	  po.clickCheckBtn(po.CheckBtn);
	  AssertJUnit.assertTrue(po.getMsg(po.SuccessMsg).contains(prop.getProperty("successMsg")));
  }
  
  @Test(priority=1)
  public void invalidPinTest() {
	 
	  po.InsertPin(prop.getProperty("invalidPin"),po.PincodeField);
	  po.clickCheckBtn(po.CheckBtn);
	  AssertJUnit.assertTrue(po.getMsg(po.ErrorMsg).contains(prop.getProperty("errorMsg")));
  }

  
  @AfterMethod
  public void afterClass() {
			driver.quit();
		}
}
