package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;


import base.ModularFunctions;
import pagesPO.HomePage;

import pagesPO.SrchResultPagePO;
import utils.ExtentReportsListener;


import org.testng.annotations.Listeners;



import org.openqa.selenium.WebDriver;

@Listeners(ExtentReportsListener.class)
public class SearchTest extends ModularFunctions {
	WebDriver driver;
	HomePage hp;
	SrchResultPagePO sp;

	@Test(priority = 0, description = "InValid Product Search")
	public void InvalidSearch() {
		hp.clickSrchBtnIcn();
		sp = hp.getSrchText("Samsung");
		AssertJUnit.assertTrue(sp.getResult());

	}
	@Test(priority = 1, description = "Valid Product Search")
	public void ValidSearch() {
		hp.clickSrchBtnIcn();
		sp = hp.getSrchText("Lotion");
		AssertJUnit.assertFalse(sp.getResult());

	}
	@BeforeClass
	public void beforeClass() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseURL"));
		hp = new HomePage(driver);
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}

}
