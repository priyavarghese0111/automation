package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.AssertJUnit;


import base.ModularFunctions;
import pagesPO.HomePage;

import pagesPO.MenCtgyProductsPO;
import utils.ExtentReportsListener;


@Listeners(ExtentReportsListener.class)
public class CertifiedOrganicTest extends ModularFunctions{
	HomePage hp;
	MenCtgyProductsPO mp;

	@Test(priority = 0, description = "Check if View Full List Link is present")
	public void CheckViewFullListLink() {
		hp.hoverOverCtgyMen();
		mp = hp.hairSubCtgy();
		mp.goToHairConProduct();
		mp.goToKeyIngredents();
		AssertJUnit.assertTrue(mp.checkViewFullListLink());

	}
	@Test(priority = 1, description = "Check if **Certified Organic is present", dependsOnMethods = "CheckViewFullListLink")
	public void CheckCerrtifiedOrganic() {
		mp.clickViewFullListLink();
		AssertJUnit.assertTrue(mp.getCertifiedOrganic());


	}
	@BeforeClass
	public void beforeClass() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseURL"));
		hp = new HomePage(driver);
	}


	@AfterClass
	public void afterClass() {
		driver.quit();
	}

}
