package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.LoginPage;
import pagesPO.WishlistToCartPage;

public class WishlistToCartTest extends ModularFunctions  {
	HomePage hp;
	LoginPage lp;
	WishlistToCartPage wc;
  @Test
  public void verify_WishlistToCart() {
	  hp=new HomePage(driver);
	  
	  //Login to the account using valid credentials
	  lp = hp.click(hp.Account);
	  wc=new WishlistToCartPage(driver);
	  lp.insertText(prop.getProperty("validemail"), lp.Email);
	  lp.insertText(prop.getProperty("validpwd"), lp.Password);
	  lp.scroll(lp.SignInBtn);
	  lp.clickElement(lp.SignInBtn);
	  AssertJUnit.assertTrue(lp.checkUrl(prop.getProperty("dashboardUrl"))); 
	  
	  //Going to wish list page and adding the items present in there to add and checking for wish list is empty message
	  wc.clickEl(wc.account1);
	  wc.clickEl(wc.wishlist);
	  wc.clickEl(wc.moveToBag);
	  wc.clickEl(wc.moveToBag1);
	  driver.navigate().refresh();
	  AssertJUnit.assertTrue(wc.isPresent(wc.errMsg));

	 
  }
  @BeforeClass
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
  }
  

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }
}
