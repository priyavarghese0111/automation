package testCases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.ModularFunctions;
import pagesPO.HomePage;
import pagesPO.ShopByConcernPage_TBD_;


public class ShopByConcernTest_TBD_  extends ModularFunctions{
	HomePage hp;
	ShopByConcernPage_TBD_ scp;
  @Test(priority=0)
  public void verify_shopByConcernIsPresent() {
	  hp=new HomePage(driver);
	  //scp=new ShopByConcernPage(driver);
	 
	  AssertJUnit.assertTrue(hp.elementPresent(hp.shopByConcern));
	 
	  scp=new ShopByConcernPage_TBD_(driver);
	  scp.clickElement(scp.clickConcern);
}
  @Test(priority=1)
  public void verify_ShopByConcern() {
	  scp=new ShopByConcernPage_TBD_(driver);
	  //scp.clickElement(scp.clickConcern);
	  AssertJUnit.assertTrue(scp.isConcernTrue());
}
  @BeforeClass
  public void beforeClass() {
	  driver = invokeBrowser();
	  driver.get(prop.getProperty("baseURL"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
  }
  

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }
}