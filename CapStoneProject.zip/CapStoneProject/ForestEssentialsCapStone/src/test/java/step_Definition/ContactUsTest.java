package step_Definition;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pagesPO.ContactUsPage;
import pagesPO.HomePage;
import utils.ExcelReader;

public class ContactUsTest {
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage hp;
	ContactUsPage cp;
	@Given("the user is in the Forestessentials Home page")
	public void the_user_is_in_the_forestessentials_home_page() {
		driver.get(properties.getProperty("baseURL"));
		hp = new HomePage(driver);
	    
	}

	@When("the user scrolls down clicks on the Contact Us navigation link")
	public void the_user_scrolls_down_clicks_on_the_contact_us_navigation_link() {
		hp = new HomePage(driver);
		hp.clickEl(hp.contactUs);
		
	}

	@When("the user enters valid details  {string},{string},{string},{string}")
	public void the_user_enters_valid_details(String string, String string2, String string3, String string4) {
		cp=new ContactUsPage(driver);
		cp.inputDetails(cp.cname, string);
		cp.inputDetails(cp.cemail, string2);
		cp.inputDetails(cp.phoneNo, string3);
		cp.inputDetails(cp.comments, string4);
		  
	}

	@And("clicks on the Submit button")
	public void clicks_on_the_submit_button() {
		cp=new ContactUsPage(driver);
		cp.clickBtn(cp.submitBtn);
	    
	}

	@Then("the user should receive a response message")
	public void the_user_should_receive_a_response_message() throws InterruptedException {
		
		Thread.sleep(5000);
		assertTrue(cp.isPresent(cp.alertmsg)); //This test passes as a response message will be displayed on the page
 
	}

	@When("enters invalid details")
	public void enters_invalid_details() {
		cp=new ContactUsPage(driver);
		cp.inputDetails(cp.cname, "a");
		cp.inputDetails(cp.cemail,"abcd.com");
		cp.inputDetails(cp.phoneNo, " ");
		cp.inputDetails(cp.comments,"!");
		
	}

	@Then("the user should receive an appropriate error message")
	public void the_user_should_receive_an_appropriate_error_message() {
		assertTrue(cp.isPresent(cp.errmsg)); //test fails because there is no error message to be shown and the user stays in the same page
	}
	 

	@When("leaves mandatory fields blank")
	public void leaves_mandatory_fields_blank() {
		cp=new ContactUsPage(driver);
		cp.inputDetails(cp.cname, " ");
		cp.inputDetails(cp.cemail," ");
		cp.inputDetails(cp.phoneNo, " ");
		cp.inputDetails(cp.comments," ");
	    
	}

	@Then("the user should receive appropriate error messages for each mandatory field")
	public void the_user_should_receive_appropriate_error_messages_for_each_mandatory_field() {
		assertTrue(cp.isPresent(cp.errmsg)); //test fails because there is no error message to be shown
		
	}
	 @DataProvider(name="dp")
	  public Object[][] dp() throws IOException {
	    String path=System.getProperty("user.dir")+"\\src\\test\\resources\\dataSource\\dataSet.xlsx";
	    
	    String sheetname="Sheet2";
	    String [][] data=ExcelReader.getData(path, sheetname);
	 // Convert 2D String array to 2D Object array
	    Object[][] objData = new Object[data.length][data[0].length];
	    for (int i = 0; i < data.length; i++) {
	        for (int j = 0; j < data[i].length; j++) {
	            objData[i][j] = data[i][j];
	        }
	    }
	    return objData;
	}
	
}

