package step_Definition;


import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import base.ElementalFunctions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pagesPO.HomePage;
import pagesPO.ThreeFacesOfBeauty;

public class verifyFacesOfBeautyDescTest {
	WebDriver driver =  Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage hp ;
	ElementalFunctions ef;
	ThreeFacesOfBeauty fb;
	
	@Given("The user is on the HomePage of ForestEssentialsindias WebApp")
	public void the_user_is_on_the_home_page_of_forest_essentialsindias_web_app() {
		driver.get(properties.getProperty("baseURL"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		hp = new HomePage(driver);
		ef =  new ElementalFunctions(driver);
		fb = new  ThreeFacesOfBeauty(driver);
	}

	@Given("User Hovers over About-Us Link on the NavTab in the HomePage")
	public void user_hovers_over_about_us_link_on_the_nav_tab_in_the_home_page() {
		hp.hoverOverCtgyAboutUs();
	}
	
	@Then("Check if the Discover Kapha link is present")
	public void check_if_the_discover_kapha_link_is_present() {
		assertTrue( hp.getKaphaSubCtgyLink().isDisplayed());
	    System.out.println( hp.getKaphaSubCtgyLink().getText()+"Link is Present");
	}

	@Then("Check if the Discover Vata link is present")
	public void check_if_the_discover_vata_link_is_present() {
		assertTrue( hp.getVataSubCtgyLink().isDisplayed());
	    System.out.println( hp.getVataSubCtgyLink().getText()+"Link is Present");
	}

	@Then("Check if the Discover Pitta link is present")
	public void check_if_the_discover_pitta_link_is_present() {
		assertTrue( hp.getPittaSubCtgyLink().isDisplayed());
	    System.out.println( hp.getPittaSubCtgyLink().getText()+"Link is Present");
	}

	@When("User clicks on the respective Kapha Link")
	public void user_clicks_on_the_respective_kapha_link() {
	    ef.clickElement(hp.getKaphaSubCtgyLink());
	}

	@Then("User scrolls down to Kaphas Description section")
	public void user_scrolls_down_to_kaphas_description_section() {
		fb.findKaphaDesc();
		System.out.println(fb.getKapha().getText());
	}

	@Then("Check if Kaphas description is correct")
	public void check_if_kaphas_description_is_correct() {
		assertEquals(fb.getKapha().getText(), properties.getProperty("Kapha"));
		System.out.println("Ok");
	}

	@When("User clicks on the respective Vata Link")
	public void user_clicks_on_the_respective_vata_link() {
		ef.clickElement(hp.getVataSubCtgyLink());
	}

	@Then("User scrolls down to Vata Description section")
	public void user_scrolls_down_to_vata_description_section() {
		fb.findVataDesc();
		System.out.println(fb.getVata().getText());
	}

	@Then("Check if Vata description is correct")
	public void check_if_vata_description_is_correct() {
		assertEquals(fb.getVata().getText(), properties.getProperty("Vata"));
		System.out.println("Ok");
	}

	@When("User clicks on the respective Pitta Link")
	public void user_clicks_on_the_respective_pitta_link() {
		ef.clickElement(hp.getPittaSubCtgyLink());
	}

	@Then("User scrolls down to Pitta Description section")
	public void user_scrolls_down_to_pitta_description_section() {
		fb.findPittaDesc();
		System.out.println(fb.getPitta().getText());
	}

	@Then("Check if Pitta description is correct")
	public void check_if_pitta_description_is_correct() {
		assertEquals(fb.getPitta().getText(), properties.getProperty("Pitta"));
		System.out.println("Ok");
	}


}
