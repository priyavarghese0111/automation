package step_Definition;

import static org.testng.AssertJUnit.assertTrue;

import org.openqa.selenium.WebDriver;

import java.time.Duration;
import java.util.Properties;

import base.ModularFunctions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pagesPO.HomePage;
import pagesPO.ProductsPage;

public class HowtoUseTest extends ModularFunctions{

	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage hp;
	ProductsPage po;
	

	
	@Given("user is in Forest Essentials Homepage")
	public void user_is_in_forest_essentials_homepage() {
		driver.get(prop.getProperty("baseURL"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); 
		 hp = new HomePage(driver);
		 po = new ProductsPage(driver);
	}

	@When("the user selects a product")
	public void the_user_selects_a_product() {
		po.scroll(hp.productClick);
	    po = hp.click1(hp.productClick);
	}

	@When("scrolls down to the How to Use section")
	public void scrolls_down_to_the_how_to_use_section() {  
	   po.scroll(po.HowToUse);
	}

	@Then("the presence of the How to Use description is validated")
	public void the_presence_of_the_how_to_use_description_is_validated() {
	    assertTrue(po.HowToUse.isDisplayed());
	}



}


