package dataProvider;



import java.io.IOException;

import org.testng.annotations.DataProvider;

import utils.ExcelReader;




public class DataProviderUtility {
  
	public static final String EXCELPATH = System.getProperty("user.dir")+ "/src/test/resources/dataSource/dataSet.xlsx";
	@DataProvider(name = "data1")
	public Object[][] dataP1() throws IOException {

		/*// To check if the data is fetched from excel
		 System.out.println("-----------Inside DataProvider-----------");
		 String[][] data = ExcelReader.getData(EXCELPATH, "Sheet1");
		 int rows = ExcelReader.getRowCount(EXCELPATH, "Sheet1");
		 int cols = ExcelReader.getColCount(EXCELPATH, "Sheet1");
		 for(int i = 0; i < rows; i++) {
			 for(int j = 0; j < cols; j++) {
				 System.out.print(data[i][j] + " ");
			 }
			 System.out.print("\n");
		 }
		 */
		return ExcelReader.getData(EXCELPATH, "Sheet1");
	}
	
	@DataProvider(name = "data2")
	public Object[][] dataP2() throws IOException {

		return ExcelReader.getData(EXCELPATH, "Sheet2");
	}
	
	@DataProvider(name = "data2")
	public Object[][] dataP3() throws IOException {

		return ExcelReader.getData(EXCELPATH, "Sheet3");
	}
	
	@DataProvider(name = "data3")
	public Object[][] dataP4() throws IOException {

		return ExcelReader.getData(EXCELPATH, "Sheet4");
	}
	
	
}

