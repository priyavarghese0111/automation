package com.ust.ReqresDemo;


import java.io.File;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.lessThan;


import org.json.simple.JSONObject;

public class ReqresDemo {
	
	@BeforeTest
	public static void beforeExecution() {
		
		RestAssured.baseURI = "https://reqres.in";
		RestAssured.useRelaxedHTTPSValidation();
	}
	
	@Test
	public void getAllUsersTest() {
		
		given()
		.when()
		.get("/api/users?page=2")
		.then()
		.assertThat()
			.statusCode(200)
			.contentType("application/json");
		
	}
	
	@Test
	public void getSingleUserTest() {
		
		given()
			.when()
				.get("/api/users/2")
				.then()
				.assertThat()
					.statusCode(200)
					.contentType("application/json").and()
					.body("data.id",equalTo(2)).and()
					.body("data.email",equalTo("janet.weaver@reqres.in")).and()
					.body("data.first_name", equalTo("Janet")).and()
					.body("data.last_name", equalTo("Weaver"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void createUserTest() {
	
		JSONObject userObj = new JSONObject();
		userObj.put("name", "Sam");
		userObj.put("job", "lead");
		
		given()
			.contentType("application/json")
			.with()
				.body(userObj.toJSONString())
			.when()
				.post("/api/users")
				.then()
				.assertThat()
					.statusCode(201).and()
					.contentType("application/json").and()
					.body("name", equalTo("Sam")).and()
					.body("job", equalTo("lead")).and()
					.body("id",not(equalTo(0)));
					
	}
	
	@SuppressWarnings("unchecked")
	public void updateUserTest() {
	
		JSONObject userObj = new JSONObject();
		userObj.put("name", "morpheus");
		userObj.put("job", "zion resident");
		
		given()
			.contentType("application/json")
			.with()
				.body(userObj.toJSONString())
			.when()
				.put("/api/users/2")
				.then()
				.assertThat()
					.statusCode(201).and()
					.contentType("application/json").and()
					.body("name", equalTo("morpheus")).and()
					.body("job", equalTo("zion resident"));
						
	}
	
	@Test
	public void deleteAnUserTest() {
		
		given()
			.when()
				.delete("/api/users/2")
				.then()
				.assertThat()
					.statusCode(204).and()
					.time(lessThan(2000l));
		
	}
	
	 @Test
	   public void validateJSONSchema(){

	      //base URL
	      RestAssured.baseURI = "https://jsonplaceholder.typicode.com/posts/2";

	      //obtain response
	      given()
	      .when().get()

	      //verify JSON Schema
	      .then().assertThat()
	      .body(JsonSchemaValidator.matchesJsonSchema(new File("C:\\Users\\271556\\Documents\\demo.json")));
	   }
	}

