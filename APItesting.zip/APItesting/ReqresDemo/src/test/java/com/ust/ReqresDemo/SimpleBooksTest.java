package com.ust.ReqresDemo;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class SimpleBooksTest {
	
	@BeforeTest
	public static void beforeExecution() {
		
		RestAssured.baseURI = "https://simple-books-api.glitch.me";
		RestAssured.useRelaxedHTTPSValidation();
	}
	
	@Test
	public void getStatusTest() {
		given()
			.when()
				.get("/status")
					.then()
					.assertThat()
					.statusCode(200)
					.contentType("application/json");

	}
	
	@Test
	public void getListOfBooksTest() {
		given()
			.when()
				.get("/books")
					.then()
					.assertThat()
					.statusCode(200)
					.contentType("application/json");
					
	
	}
	
	@Test
	public void getSingleBookTest() {
		given()
			.when()
			.get("/books/2")
				.then()
				.assertThat()
				.statusCode(200)
				.contentType("application/json").and()
				.body("id",equalTo(2)).and()
				.body("name",equalTo("Just as I Am")).and()
				.body("author", equalTo("Cicely Tyson"));
				
			
	}
	
	@Test
	public void RegisterAPITest() {
		given()
				.contentType("application/json")
				.with()
				 	.body("{\r\n"
				 			+ "   \"clientName\": \"Priya\",\r\n"
				 			+ "   \"clientEmail\": \"priya@example.com\"\r\n"
				 			+ "}")
				 .when()
				 	.post("/api-clients")
				 		.then()
				 		.assertThat()
				 		.statusCode(409)
				 		.contentType("application/json");
	}

	
	@Test
	public void OrderBookTest() {
		given()
		        .header(null)
				.contentType("application/json")
				.with()
				 	.body("{\r\n"
				 			+ "  \"bookId\": 1,\r\n"
				 			+ "  \"customerName\": \"John\"\r\n"
				 			+ "}")
				 .when()
				 	.post("/orders")
				 		.then()
				 		.assertThat()
				 		.statusCode(201)
				 		.contentType("application/json");
	}

}
