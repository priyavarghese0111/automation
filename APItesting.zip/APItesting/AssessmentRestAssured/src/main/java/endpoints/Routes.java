package endpoints;

public class Routes {
	
	public static final String baseuri = "https://jsonplaceholder.typicode.com";
	public static final String singleReourceBasePath = "/posts/{id}";
	public static final String listOfResource = "/posts?userId={id}";
	public static final String nestedResource = "/posts/{id}/comments";
	public static final String filteredResource = "/comments?postId={id}";
	public static final String createResource = "/posts";
	public static final String updateResource = "/posts/{id}";
	public static final String patchResource = "/posts/{id}";
	public static final String deleteResource = "/posts/{id}";
	
	public static final String baseurii = "https://jsonplaceholder.typicode.com/posts/1";


}
