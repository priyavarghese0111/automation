package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.JsonModel;

import static io.restassured.RestAssured.given;



public class JsonEndPoints {
	
	public static Response getSingleResource(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
			             ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
				.baseUri(Routes.baseuri)
                .basePath(Routes.singleReourceBasePath)
			    .pathParam("id", id)
			    .contentType("application/json")
			    .accept(ContentType.JSON)
			    .when()
		        .get();
		return response;
	}
	
	public static Response getListOfResources() {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						 ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.listOfResource)
				.contentType("application/json")
				.accept(ContentType.JSON)
			    .when()
				.get();
       return response;
							
	}
	
	public static Response getNestedResources(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.nestedResource)
				.pathParam("id",id)
				.contentType(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	
	public static Response getfilteredResources(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.filteredResource)
				.queryParam("postId", id)
				.contentType(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	
	
	public static Response CreateResource(JsonModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.createResource)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
		
	}
	
	
	public static Response UpdateResource(int id, JsonModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.updateResource)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
	public static Response PatchResource(int id,JsonModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.patchResource)
				.pathParam("id",id)
				.contentType(ContentType.JSON)
				.body(payload)
				.when()
				.patch();
		return response;
	}
	
	
	public static Response DeleteResource(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.deleteResource)
				.pathParam("id",id)
				.contentType(ContentType.JSON)
				.when()
				.delete();
		return response;
	}
	
	

}
