package tests;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.hamcrest.Matchers.*;

import java.io.File;

import endpoints.JsonEndPoints;
import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import payload.JsonModel;


@Listeners(utilities.ExtentReportsListener.class)
public class JsonTest {
	
public static JsonModel userpayload;
	
	@BeforeClass
	public static void beforeExecution() {
		userpayload = new JsonModel(1,"foo","bar",1);
		RestAssured.useRelaxedHTTPSValidation();
	}
	
	@Test(priority=0)
	public void getSingleResourceTest() {
		Response response = JsonEndPoints.getSingleResource(this.userpayload.getId());//getting the response from the JsonEndpoint
		response.then().log().all();//printing the response in console
		response.then().body("title",equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit"));//asserting the response body
		Assert.assertEquals(response.getStatusCode(),200);//asserting the status code
	}
	
	@Test(priority=1)
	public void getListOfResourceTest()
    {
      Response response = JsonEndPoints.getListOfResources();//getting the response from the JsonEndpoint
      response.then().log().all();//printing the response in console
      Assert.assertEquals(response.getStatusCode(),200);//asserting the status code
    }
	
	 @Test(priority=2)
	    public void NestedResourceTest() {
	    	Response response = JsonEndPoints.getNestedResources(this.userpayload.getId());//getting the response from the JsonEndpoint
	    	response.then().log().all();//printing the response in console
	    	response.then().body("name[2]",equalTo("odio adipisci rerum aut animi"));
	    	Assert.assertEquals(response.getStatusCode(),200);//asserting the status code
	    }
	 
	 @Test(priority=3)
	 public void FilteredResourceTest() {
		 Response response = JsonEndPoints.getfilteredResources(this.userpayload.getId());//getting the response from the JsonEndpoint
		 response.then().log().all();//printing the response in console
		 response.then().body("email[0]",equalTo("Eliseo@gardner.biz"));//asserting the response body
		 Assert.assertEquals(response.getStatusCode(),200);//asserting the status code
	 }
	 
	 
	 @Test(priority=4)
	    public void CreateAResourceTest()
	    {
	    	JsonModel userpayload1 = new JsonModel("foo","bar",1);
	    	Response response = JsonEndPoints.CreateResource(userpayload1);//getting the response from the JsonEndpoint
	    	response.then().log().all();//printing the response in console
	    	response.then().body("body",equalTo("bar"));//asserting the response body
	    	Assert.assertEquals(response.getStatusCode(),201);//asserting the status code
	    }

	 
	 @Test(priority=5)
	    public void UpdateResourceTest() {
	    	Response response = JsonEndPoints.UpdateResource(this.userpayload.getId(), userpayload);//getting the response from the JsonEndpoint
	    	response.then().log().all();//printing the response in console
	    	response.then().body("title", equalTo("foo"));//asserting the response body
	    	Assert.assertEquals(response.statusCode(), 200);//asserting the status code
	    }
	 
	 @Test(priority=6)
	    public void PatchResourceTest() {
	    
		 JsonModel userpayload2 = new JsonModel(1,"foo","bar",1);
	    	Response response = JsonEndPoints.PatchResource(this.userpayload.getId(),userpayload2);//getting the response from the JsonEndpoint
	    	response.then().log().all();//printing the response in console
	    	response.then().body("body", equalTo("bar"));//asserting the response body
	    	Assert.assertEquals(response.statusCode(),200);//asserting the status code
	    }
	 
	 @Test(priority=7)
	    public void DeleteResourceTest() {
	    	Response response = JsonEndPoints.DeleteResource(this.userpayload.getId());//getting the response from the JsonEndpoint
	    	response.then().log().all();//printing the response in console
	    	Assert.assertEquals(response.statusCode(),200);//asserting the status code
	    }
	 
	 
	 @Test(priority=8)
	    public void SchemaValidation() {
	    	
		    RestAssured.given()
		    .baseUri(Routes.baseurii)
		        .when()
		        .get()
		        .then()
		        .assertThat().statusCode(200)
		        .body(matchesJsonSchema(new File("C:\\Users\\271556\\Desktop\\APItesting\\AssessmentRestAssured\\src\\test\\resources\\schema.json")));//validating the schema
		    

	    }
}
