package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EmployeeEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.EmployeeModel;


@Listeners(utilities.ExtentReportsListener.class)
public class EmployeeTest {

	
	public static EmployeeModel userpayload;
	
	@BeforeClass
	public static void beforeExecution() {
		userpayload = new EmployeeModel("test","123","23");
		
	}
	
	 @Test(priority=0)
	    public void getAllUsersTest()
	    {
	      RestAssured.useRelaxedHTTPSValidation();
	      Response response = EmployeeEndpoints.getAllEmployees();
	      response.then().log().all();
	      response.then().body("data[0].employee_name",equalTo("Tiger Nixon"));
	      Assert.assertEquals(response.getStatusCode(), 200);
	      
	    }
	 
	 @Test(priority=1)
	    public void getSingleUserTest()
	    {
	      RestAssured.useRelaxedHTTPSValidation();
	      Response response = EmployeeEndpoints.getSingleEmployees(1);
	      response.then().log().all();
	      Assert.assertEquals(response.getStatusCode(), 200);
	      
	    }
	 
	 @Test(priority=2)
	    public void CreateUserTest()
	    {
	    	RestAssured.useRelaxedHTTPSValidation();
	    	Response response = EmployeeEndpoints.CreateUser(userpayload);
	    	response.then().log().all();
	    	Assert.assertEquals(response.getStatusCode(),200);
	    		
	    }
	
	 @Test(priority=3)
	    public void UpdateUserTest()
	    {
	    	RestAssured.useRelaxedHTTPSValidation();
	    	Response response = EmployeeEndpoints.UpdateUser(21,userpayload);
	    	response.then().log().all();
	    	Assert.assertEquals(response.getStatusCode(),200);
	    		
	    }
	 
	 @Test(priority=4)
	    public void DeleteUserTest()
	    {
	    	RestAssured.useRelaxedHTTPSValidation();
	    	Response response = EmployeeEndpoints.deleteUser(2);
	    	response.then().log().all();
	    	Assert.assertEquals(response.getStatusCode(),200);
	    		
	    }
	 
	 @Test(priority=4)
	    public void SchemaValidation() {
	    	RestAssured.useRelaxedHTTPSValidation();
		    RestAssured.given()
		    .baseUri(endpoints.Routes.baseurii)
		        .when()
		        .get()
		        .then()
		        .assertThat().statusCode(200)
		        .body(matchesJsonSchema(new File("C:\\Users\\271556\\Desktop\\APItesting\\APIMock\\src\\test\\resources\\schema.json")));
		    

	    }
	
}
