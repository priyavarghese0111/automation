package endpoints;

public class Routes {
	
	public static final String Baseuri = "https://dummy.restapiexample.com/api/v1";
	public static final String GetAllUsers = "/employees";
	public static final String GetSingleUser = "/employee/{id}";
	public static final String CreateUser = "/create";
	public static final String UpdateUser = "/update/{id}";
	public static final String DeleteUser = "/delete/{id}";
	public static final String baseurii = "https://dummy.restapiexample.com/api/v1/employees";
	

}
