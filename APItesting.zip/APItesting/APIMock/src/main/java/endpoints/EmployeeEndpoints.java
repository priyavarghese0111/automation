package endpoints;

import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.EmployeeModel;


public class EmployeeEndpoints {

	public static Response getAllEmployees() {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
			             ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
											.baseUri(Routes.Baseuri)
											.basePath(Routes.GetAllUsers)
											.contentType("application/json")
											.accept(ContentType.JSON)
										.when()
											.get();
		return response;
	}
	
	
	
	public static Response getSingleEmployees(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
			             ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
											.baseUri(Routes.Baseuri)
											.basePath(Routes.GetSingleUser)
											.pathParam("id", id)
											.contentType("application/json")
											.accept(ContentType.JSON)
										.when()
											.get();
		return response;
	}
	
	
	public static Response CreateUser(EmployeeModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.Baseuri)
				.basePath(Routes.CreateUser)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
		
	}
	
	public static Response UpdateUser(int id,EmployeeModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.Baseuri)
				.basePath(Routes.UpdateUser)
				.pathParam("id",id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
		
	}
	
	public static Response deleteUser(int id) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
			             ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
											.baseUri(Routes.Baseuri)
											.basePath(Routes.DeleteUser)
											.pathParam("id", id)
											.contentType("application/json")
											.accept(ContentType.JSON)
										.when()
											.delete();
		return response;
	}
}


