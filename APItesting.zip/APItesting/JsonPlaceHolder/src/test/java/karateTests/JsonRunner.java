package karateTests;

import com.intuit.karate.junit5.Karate;

public class JsonRunner {
	
	@Karate.Test
	public Karate runTest() {
		return Karate.run("classpath:karateTests/Json.feature").relativeTo(getClass());	
	}

}
