package Endpoint;

public class Routes {
	
	public static String baseuri = "https://jsonplaceholder.typicode.com";
	public static String singleReourceBasePath = "/posts/{id}";
	public static String listOfResource = "/posts?userId={id}";
	public static String createResource = "/posts";
	public static String updateResource = "/posts/{id}";
	public static String patchResource = "/posts/{id}";
	public static String deleteResource = "/posts/{id}";
	public static String nestedResource = "/posts/{id}/comments";
	public static String baseurii = "https://jsonplaceholder.typicode.com/posts/1";

}
