package tests;


import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.jupiter.api.Test;
import org.testng.annotations.Listeners;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Listeners(utilities.ExtentReportsListener.class)
public class ApiTest {

    @Test
	public void getList() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getList();
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
		
	}
    
    @Test
    public void testSchema() {
    	RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(endpoints.Routes.Baseuriii)
	        .when()
	        .get()
	        .then()
	        .assertThat().statusCode(200)
	        .body(matchesJsonSchema(new File("C:\\Users\\271556\\Desktop\\APItesting\\APIFramework\\src\\test\\resources\\schema.json")));
	    
    }
}
