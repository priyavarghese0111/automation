package endpoints;

public class Routes {
	
		public static final String Baseuri = "http://universities.hipolabs.com";
		public static final String GetBasePath = "/search";
		public static final String Baseuriii = "http://universities.hipolabs.com/search?name=middle";

}
