package endpoints;

import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UserEndpoints {
	
	public static Response getList() {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						 ContentType.JSON,
			             "Accept",
			             ContentType.JSON)
				.baseUri(Routes.Baseuri)
				.basePath(Routes.GetBasePath)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.queryParam("name", "middle")
			.when()
				.get();
       return response;
							
	}

}
