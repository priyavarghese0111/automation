package payload;

public class UserModel {

}
