package payload;

public class UserModel {

	public long id;
	public String email;
	public String fname;
	public String lname;
	public String avatar;
	
	public UserModel() {
	}
	
	public UserModel(long id,String email,String fname,String lname,String avatar) {
		this.id=id;
		this.email=email;
		this.fname=fname;
		this.lname=lname;
		this.avatar=avatar;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	
	
}
