package Endpoint;



import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.UserModel;

public class UserEndpoints {
	
	public static Response getUserlist(long id) {
		Response response = RestAssured.given()
				.headers(	
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.BaseUri)
				.basePath(Routes.Get_list)
				.queryParam("page", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
	
	public static Response postCreateUsers(UserModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.BaseUri)
				.basePath(Routes.Post_create)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
				
	}
	
	public static Response putUser(long id,UserModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.BaseUri)
				.basePath(Routes.Put_update)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;
				
	}
	
	public static Response patchUser(long id,UserModel payload) {
		Response response = RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.BaseUri)
				.basePath(Routes.Patch_update)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;
	}
	
	
	public static Response deleteUser(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.BaseUri)
				.basePath(Routes.Delete_user)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;	
	}
	
	

}
