package Endpoint;

public class Routes {
	
	public static final String BaseUri = "https://reqres.in";
	public static final String Get_list = "/api/users?";
	public static final String Get_single = "/api/users/{id}";
	public static final String Post_create = "/api/users";
	public static final String Put_update = "api/users/{id}";
	public static final String Patch_update = "api/users/{id}";
	public static final String Delete_user = "api/users/{id}";
}
