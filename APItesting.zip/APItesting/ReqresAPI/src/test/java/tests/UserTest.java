package tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Endpoint.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.UserModel;

public class UserTest {

	public UserModel payload;
	
	
	@BeforeClass
	public void setUp() {
		payload = new UserModel(2,"janet.weaver@reqres.in", "janet", "weaver","https://reqres.in/img/faces/2-image.jpg");
	}
	
	
	@Test(priority=0)
	public void getListUsersTest() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getUserlist(this.payload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	
	@Test(priority=1)
	public void postCreateUsersTest() {
//		RestAssured.useRelaxedHTTPSValidation();
//		UserModel userpayload1 = new UserModel(5,"priya123@gmail.com","priya","varghese","https://reqres.in/img/faces/2-image.jpg");
		Response response = UserEndpoints.postCreateUsers(payload);
		response.then().log().all();
		assertEquals(response.getStatusCode(),201);
	}
	
	
	@Test(priority=2)
	public void putUsersTest() {
		RestAssured.useRelaxedHTTPSValidation();
		UserModel userpayload2 = new UserModel(5,"priya456@gmail.com","priya","varghese","https://reqres.in/img/faces/2-image.jpg");
		Response response = UserEndpoints.putUser(5,userpayload2);
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
	}
	
	
	@Test(priority=3)
	public void patchUsersTest() {
		RestAssured.useRelaxedHTTPSValidation();
		UserModel userpayload2 = new UserModel(5,"priya123@gmail.com","priyaaaaa","varghesee","https://reqres.in/img/faces/2-image.jpg");
		 Response response  = UserEndpoints.patchUser(5, userpayload2);
		 response.then().log().all();
		 assertEquals(response.getStatusCode(),200);
		 
	}
	
	
	@Test(priority=4)
	public void deleteUsersTest() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.deleteUser(5);
		response.then().log().all();
		assertEquals(response.getStatusCode(),204);
	}
}
