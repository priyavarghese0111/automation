package karateTest;

import com.intuit.karate.junit5.Karate;

public class JsonRunner {
	
	@Karate.Test
	public Karate runTest() {
		return Karate.run("Json.feature").relativeTo(getClass());	
	}

}
