package com.ust.RestAssured;



import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import com.ust.api_restAssured.ReqresAPI;
import com.ust.api_restAssured.createUserPayload;

import io.restassured.RestAssured;

public class ReqresTestNGSuite {
ReqresAPI obj1 = new ReqresAPI();
	

    createUserPayload objPayload = new createUserPayload();
	
	@Test(dataProvider="getData")
	public void createUserPayloadParams(String name, String job) {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI="https://reqres.in";
		given().log().all()
		.header("Content-Type","application/json")
		.body(objPayload.payloadparams(name, job))
		.when().post("/api/users")
		.then().log().all().assertThat().statusCode(201);
	}

	
	@DataProvider
	public Object[][] getData(){
		Object[][] data = new Object[3][2];
		data[0][0]="Suresh";
        data[0][1]="Manager";

        data[1][0]="Neeta";
        data[1][1]="Lead";

        data[2][0]="Vignesh";
        data[2][1]="HR";
        return data;
	}


}
