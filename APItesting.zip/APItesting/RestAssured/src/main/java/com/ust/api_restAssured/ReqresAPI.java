package com.ust.api_restAssured;
import static org.hamcrest.Matchers.equalTo;
import static io.restassured.RestAssured.given;
 
import org.testng.annotations.Test;
 
import io.restassured.RestAssured;

//java lib to automated api 
public class ReqresAPI {

	public void getAllUsers() {
	RestAssured.useRelaxedHTTPSValidation();
	RestAssured.baseURI="https://reqres.in/";
	given().log().all().queryParam("page", 2) //log.all is for reading console i.e.getting console .it is given only in given() and then()
	.when().get("/api/users")
	.then().log().all().assertThat().statusCode(200)
	.body("total", equalTo(12));
	}
 
	
	public static void main(String[] args) {
	ReqresAPI listAllUsersObj = new ReqresAPI();
	listAllUsersObj.getAllUsers();
	listAllUsersObj.getSingleUser();
	listAllUsersObj.createUser();
	}
 
	public static void getSingleUser() {
	RestAssured.useRelaxedHTTPSValidation();
	RestAssured.baseURI="https://reqres.in/";
	given().log().all()
	.when().get("/api/users")
	.then().log().all().assertThat().statusCode(200)
	.body("last_name",equalTo("Weaver"));
	}
	
	
	public static void createUser() {
	RestAssured.useRelaxedHTTPSValidation();
	RestAssured.baseURI="https://reqres.in/";
	given().log().all().body("{\r\n"
			+ "    \"name\": \"morpheus\",\r\n"
			+ "    \"job\": \"leader\"\r\n"
			+ "}")
	.when().post("/api/users")
	.then().log().all().assertThat().statusCode(200)
	.body("job",equalTo("leader"));
	}
	
	
	@Test(dataProvider = "getData")
	public static void createUserDataDriven(String name, String job) {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = "https://reqres.in";
		given().log().all().header("Content-Type", "application/json; charset=utf-8")
		.body(createUserPayload.payloadparams(name, job))
		.when().post("/api/users")
		.then().log().all().assertThat().statusCode(201);
		// .body("data.job", equalTo("leader"));
	}

 
}