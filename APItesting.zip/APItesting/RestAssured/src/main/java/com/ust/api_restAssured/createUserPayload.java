package com.ust.api_restAssured;

public class createUserPayload {

	public static String payload() {
		return "{\r\n" + "    \"name\": \"morpheus\",\r\n" + "    \"job\": \"leader\"\r\n" + "}\r\n" + "}";
	}
	
	    public static String payloadparams(String name, String job) {
	        return "{\r\n"
	                + "    \"name\": \"" + name + "\",\r\n"
	                + "    \"job\": \"" + job + "\"\r\n"
	                + "}\r\n";
	    }
}
