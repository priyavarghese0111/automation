package com.ust.api_restAssured;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class ReqresNew {
	public static void updateUser() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI="https://reqres.in/";
		given().log().all().body("{\n"
				+ "    \"name\": \"morpheus\",\n"
				+ "    \"job\": \"zion resident\"\n"
				+ "}")
		
		.when().post("/api/users")
		.then().log().all().assertThat().statusCode(200)
		.body("job",equalTo("zion resident"));
		}
		
}
