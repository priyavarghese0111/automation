package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Endpoint.JsonEndPoints;
import Endpoint.Routes;

import static org.hamcrest.Matchers.*;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.JsonModel;


public class JsonDemo 
{
	public static JsonModel userpayload;
	
	@BeforeClass
	public static void beforeExecution() {
		userpayload = new JsonModel(1,"foo","bar",1);
		
	}
	
    
    @Test(priority=0)
    public void getSingleResourceTest()
    {
      RestAssured.useRelaxedHTTPSValidation();
      Response response = JsonEndPoints.getSingleResource(this.userpayload.getId());
      response.then().log().all();
      Assert.assertEquals(response.getStatusCode(), 200);
    }
    
    @Test(priority=1)
    public void getListOfResourceTest()
    {
      RestAssured.useRelaxedHTTPSValidation();
      Response response = JsonEndPoints.getListOfResources();
      response.then().log().all();
      Assert.assertEquals(response.getStatusCode(),200);
    }

    
    @Test(priority=2)
    public void CreateAResourceTest()
    {
    	RestAssured.useRelaxedHTTPSValidation();
    	JsonModel userpayload1 = new JsonModel("foo","bar",1);
    	Response response = JsonEndPoints.CreateResource(userpayload1);
    	response.then().log().all();
    	Assert.assertEquals(response.getStatusCode(),201);
    	
    	
    }
    
    @Test(priority=3)
    public void UpdateResourceTest() {
    	RestAssured.useRelaxedHTTPSValidation();
    	Response response = JsonEndPoints.UpdateResource(JsonDemo.userpayload.getId(), userpayload);
    	response.then().log().all();
    	Assert.assertEquals(response.statusCode(), 200);
    }
    
    @Test(priority=4)
    public void PatchResourceTest() {
    	RestAssured.useRelaxedHTTPSValidation();
    	JsonModel userpayload2 = new JsonModel(1,"foo","bar",1);
    	Response response = JsonEndPoints.PatchResource(JsonDemo.userpayload.getId(),userpayload2);
    	response.then().log().all();
    	Assert.assertEquals(response.statusCode(),200);
    }
    
    
    @Test(priority=5)
    public void DeleteResourceTest() {
    	RestAssured.useRelaxedHTTPSValidation();
    	Response response = JsonEndPoints.DeleteResource(JsonDemo.userpayload.getId());
    	response.then().log().all();
    	Assert.assertEquals(response.statusCode(),200);
    }
    
    @Test(priority=6)
    public void NestedResourceTest() {
    	RestAssured.useRelaxedHTTPSValidation();
    	Response response = JsonEndPoints.NestedResources(JsonDemo.userpayload.getId());
    	response.then().log().all();
    	Assert.assertEquals(response.getStatusCode(),200);
    }
    
    
    @Test(priority=7)
    public void SchemaValidation() {
    	RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseurii)
	        .when()
	        .get()
	        .then()
	        .assertThat().statusCode(200)
	        .body(matchesJsonSchema(new File("C:\\Users\\271556\\Desktop\\APItesting\\JsonPlaceHolder\\src\\test\\resources\\schema.json")));
	    

    }
}
