package karateTest;

import com.intuit.karate.junit5.Karate;

public class ReqresRunner {

	
	@Karate.Test
	public Karate runTest() {
		return Karate.run("Reqres.feature").relativeTo(getClass());	
	}

}
